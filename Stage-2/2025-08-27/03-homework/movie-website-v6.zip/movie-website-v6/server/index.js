const express = require("express");
const cors = require("cors");
const app = express();
const port = 3000;

app.use(express.json());
app.use(cors());

// Database connection
const mysql = require("mysql2/promise");
const db = mysql.createPool({
    host: "localhost",
    user: "your_username",
    password: "your_password",
    database: "your_database",
});

/*
 *   ↑↑↑ DO NOT change the code above this comment
 *   =============================================
 *   ↓↓↓ ADD your code below this comment
 */

// Root route
app.get("/", (req, res) => {
    // Send a response
    res.send("Hello World!");
});

// Create a route to get all genres
app.get("/genres", async (req, res) => {
    // Query the database for all genres
    const results = await db.query(`
        SELECT genre_id, name 
        FROM genres 
        ORDER BY name
    `);

    // Send the results as the response
    res.send(results[0]);
});

// Create a route to get all movies for a specific genre
app.get("/genre/:genre_id", async (req, res) => {
    // Get the genre_id from the request parameters
    const genreId = req.params.genre_id;

    // Query the database for all movies for the specific genre
    const results = await db.query(`
        SELECT 
            m.movie_id,
            m.title,
            m.release_year,
            m.duration_minutes,
            m.description,
            d.name AS director_name,
            COUNT(r.review_id) AS numberOfReviews,
            ROUND(AVG(r.rating), 1) AS averageRating
        FROM movies m
        JOIN directors d ON m.director_id = d.director_id
        JOIN movie_genres mg ON m.movie_id = mg.movie_id
        JOIN reviews r ON r.movie_id=m.movie_id
        WHERE mg.genre_id = ${genreId}
        GROUP BY m.movie_id
        ORDER BY m.release_year DESC, m.title
    `);

    // Send the results as the response
    res.send(results[0]);
});

// Create a route to get a specific movie by its ID
app.get("/movies/:movie_id", async (req, res) => {
    // Get the movie_id from the request parameters
    const movieId = req.params.movie_id;

    // Query the database for all movies for the specific genre
    const results = await db.query(`
        SELECT 
            m.movie_id,
            m.title,
            m.release_year,
            m.duration_minutes,
            m.description,
            m.trailer_url,
            m.poster_url,
            d.name AS director_name,
            COUNT(r.review_id) AS numberOfReviews,
            ROUND(AVG(r.rating), 1) AS averageRating
        FROM movies m
        JOIN directors d ON m.director_id = d.director_id
        JOIN reviews r ON r.movie_id=m.movie_id
        WHERE m.movie_id = ${movieId}
        GROUP BY m.movie_id
        ORDER BY m.release_year DESC, m.title
    `);

    // Send the results as the response
    res.send(results[0][0]);
});

/*
 *   ↑↑↑ ADD your code above this comment
 *   =============================================
 *   ↓↓↓ DO NOT change the code below this comment
 */
app.listen(port, () => {
    console.log(`Server app listening at http://localhost:${port}`);
});
