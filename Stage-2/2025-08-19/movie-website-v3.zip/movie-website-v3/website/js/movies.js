let movies = [];

function createMovieCard(movie) {
    return `
        <article class="card">
            <img
                src="${movie.poster}"
                alt="Poster of ${movie.title}"
            />
            <div class="card-body">
                <div class="card-title">
                    ${movie.title} <span class="card-sub">(${movie.year})</span>
                </div>
                <div class="meta">
                    <strong>Director:</strong> 
                    ${movie.director}
                </div>
                <div class="meta"><strong>Rating:</strong> ${movie.rating}</div>
                <div class="meta"><strong>Genre:</strong> ${movie.genre}</div>
                <p>
                    ${movie.description}
                </p>
                <div class="meta">
                    <strong>Actors:</strong> ${movie.actors.join(", ")}
                </div>
            </div>
        </article>  
    `;
}

function displayCards(movies, displayElement) {
    displayElement.innerHTML = "";
    for (let i = 0; i < movies.length; i++) {
        displayElement.innerHTML += createMovieCard(movies[i]);
    }
}

function loadMoviesHomepage() {
    fetch("http://localhost:3000")
        .then(function (response) {
            return response.text();
        })
        .then(function (data) {
            const movies = JSON.parse(data);
            for (let i = 0; i < movies.length; i++) {
                const displayElement = document.getElementById(movies[i].genre);
                displayCards(movies[i].movies, displayElement);
            }
        });
}

function loadMoviesGenre(route, displayElementId) {
    const displayElement = document.getElementById(displayElementId);

    fetch("http://localhost:3000" + route)
        .then(function (response) {
            return response.text();
        })
        .then(function (data) {
            movies = JSON.parse(data);
            displayCards(movies, displayElement);
        });
}

function searchMovies(displayElementId) {
    const displayElement = document.getElementById(displayElementId);
    const searchInput = document.getElementById("search-input");
    const searchTerm = searchInput.value.toLowerCase();

    const filteredMovies = movies.filter(
        (movie) =>
            movie.title.toLowerCase().includes(searchTerm) ||
            movie.description.toLowerCase().includes(searchTerm) ||
            movie.actors.some((actor) =>
                actor.toLowerCase().includes(searchTerm)
            )
    );

    displayCards(filteredMovies, displayElement);
}

function sortMovies(displayElementId) {
    const displayElement = document.getElementById(displayElementId);
    const sortSelect = document.getElementById("sort-select");
    const selectedOption = sortSelect.value;

    if (selectedOption === "rating-asc") {
        movies.sort((a, b) => a.rating - b.rating);
    } else if (selectedOption === "rating-desc") {
        movies.sort((a, b) => b.rating - a.rating);
    } else if (selectedOption === "year-asc") {
        movies.sort((a, b) => a.year - b.year);
    } else if (selectedOption === "year-desc") {
        movies.sort((a, b) => b.year - a.year);
    }
    displayCards(movies, displayElement);
}
