const express = require("express");
const cors = require("cors");
const app = express();
const port = 3000;

app.use(express.json());
app.use(cors());

// Database connection
const mysql = require("mysql2/promise");
const db = mysql.createPool({
    host: "localhost",
    user: "your_user",
    password: "your_password",
    database: "your_database",
});

/*
 *   ↑↑↑ DO NOT change the code above this comment
 *   =============================================
 *   ↓↓↓ ADD your code below this comment
 */

// Root route
app.get("/", async (req, res) => {
    // Send a response
    res.send("Hello World!");
});

// Create a route to get all genres
app.get("/genres", async (req, res) => {
    // Query the database for all genres
    const results = await db.query(`
        SELECT genre_id, name 
        FROM genres 
        ORDER BY name
    `);

    // Send the results as the response
    res.send(results[0]);
});

// Create a route to get all movies for a specific genre
app.get("/genre/:genre_id", async (req, res) => {
    // Get the genre_id from the request parameters
    const genreId = req.params.genre_id;

    // Query the database for all movies for the specific genre
    const results = await db.query(`
        SELECT 
            m.movie_id,
            m.title,
            m.release_year,
            m.duration_minutes,
            m.description,
            d.name AS director_name
        FROM movies m
        JOIN directors d ON m.director_id = d.director_id
        JOIN movie_genres mg ON m.movie_id = mg.movie_id
        WHERE mg.genre_id = ${genreId}
        ORDER BY m.release_year DESC, m.title
    `);

    // Send the results as the response
    res.send(results[0]);
});

/*
 *   ↑↑↑ ADD your code above this comment
 *   =============================================
 *   ↓↓↓ DO NOT change the code below this comment
 */
app.listen(port, () => {
    console.log(`Server app listening at http://localhost:${port}`);
});
