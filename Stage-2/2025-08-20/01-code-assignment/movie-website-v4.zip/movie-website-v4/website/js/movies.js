function createMovieCard(movie) {
    return `
        <article class="card">
            <img
                src="${movie.poster}"
                alt="Poster of ${movie.title}"
            />
            <div class="card-body">
                <div class="card-title">
                    ${movie.title} 
                    <span class="card-sub">
                        (${movie.year})
                    </span>
                </div>
                <div class="meta">
                    <strong>Director:</strong>
                    ${movie.director}
                </div>
                <div class="meta">
                    <strong>Rating:</strong> 
                    ${movie.rating}
                    out of 
                    ${movie.reviewCount}
                    reviews
                </div>
                <div class="meta">
                    <strong>Genre:</strong> 
                    ${movie.genre}
                </div>
                <p>
                    ${movie.description}
                </p>
                <div class="meta">
                    <strong>Actors:</strong> 
                    ${movie.actors.join(", ")}
                </div>
                <div class="meta">
                    <a href="movie.html?id=${movie.id}">Go to Movie Details</a>
                </div>
            </div>
        </article>
    `;
}
